const phone='919999999999';let cart={};
const s=document.createElement('script');s.src='products.js';document.head.appendChild(s);
s.onload=()=>{let l=document.getElementById('list');products.forEach((p,i)=>{l.innerHTML+=`<div class=card><img src="${p.img}"><h4>${p.name}</h4><p>₹${p.price}/kg</p><input type=number id=q${i} min=1 value=1><button onclick='add(${i})'>Add</button></div>`})}
function add(i){let q=+document.getElementById('q'+i).value;cart[products[i].name]={q,price:products[i].price};show()}
function show(){let t='',tot=0;for(let k in cart){let v=cart[k],a=v.q*v.price;tot+=a;t+=`${k} - ${v.q}kg - ₹${a}\n`;}t+='Total: ₹'+tot;document.getElementById('cart').textContent=t;}
function sendWA(){let msg=document.getElementById('cart').textContent;window.open(`https://wa.me/${phone}?text=${encodeURIComponent(msg)}`)}