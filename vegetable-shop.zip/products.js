const products=[
{name:'Tomato',price:40,img:'https://via.placeholder.com/80?text=Tomato'},
{name:'Onion',price:30,img:'https://via.placeholder.com/80?text=Onion'},
{name:'Potato',price:35,img:'https://via.placeholder.com/80?text=Potato'}];